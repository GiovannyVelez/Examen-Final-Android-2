package com.example.giovannydavid.animacion;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Handler;
import android.util.AttributeSet;
import android.widget.ImageView;

/**
 * Created by giovannydavid on 11/07/2016.
 */
public class animacion extends ImageView {
    Context ct;
    float posX, posY;
    private Handler handler;
    float velX, velY;


    public animacion(Context context, AttributeSet attrs) {
        super(context, attrs);
        ct = context;
        posX = 150;
        posY = 0;
        velX = 0;
        velY = 50;
    }

    @Override
    protected void onDraw(Canvas canvas)
    {
        Bitmap bmp = BitmapFactory.decodeResource(ct.getResources(), R.drawable.cube);
        canvas.drawBitmap(bmp, posX, posY, null);
        handler = new Handler();
        posX += velX;
        posY += velY;
        handler.postDelayed(runnable,50);
        if (posY == 500)
        {
            velY = -50;
        }
        if (posY == 0)
        {
            velY = 50;
        }

    }
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            invalidate();
        }
    };



}